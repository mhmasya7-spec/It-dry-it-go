package com.example.platehunter

import java.io.File

/** Splits an AAC (ADTS) recording into overlapping chunks at frame boundaries; every chunk is a valid standalone .aac file. */
object AdtsSplitter {
    class Chunk(val file: File, val startSec: Double, val lengthSec: Double, val temp: Boolean)

    private val rates = intArrayOf(96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350)

    fun split(src: File, dir: File, chunkSec: Double, overlapSec: Double): List<Chunk> {
        val data = src.readBytes()
        val offs = ArrayList<Int>(); val lens = ArrayList<Int>()
        var i = 0; var rate = 16000
        while (i + 7 <= data.size) {
            if ((data[i].toInt() and 0xFF) != 0xFF || (data[i + 1].toInt() and 0xF0) != 0xF0) { i++; continue } // resync
            val len = ((data[i + 3].toInt() and 0x03) shl 11) or ((data[i + 4].toInt() and 0xFF) shl 3) or ((data[i + 5].toInt() and 0xE0) shr 5)
            if (len < 7 || i + len > data.size) break
            if (offs.isEmpty()) rates.getOrNull((data[i + 2].toInt() and 0x3C) shr 2)?.let { rate = it }
            offs.add(i); lens.add(len); i += len
        }
        val frameSec = 1024.0 / rate
        val total = offs.size
        val totalSec = total * frameSec
        if (total == 0 || totalSec <= chunkSec * 1.25) return listOf(Chunk(src, 0.0, if (total == 0) 0.0 else totalSec, false))
        val per = (chunkSec / frameSec).toInt()
        val step = ((chunkSec - overlapSec) / frameSec).toInt().coerceAtLeast(1)
        dir.mkdirs()
        val out = ArrayList<Chunk>()
        var s = 0; var k = 0
        while (s < total) {
            val e = minOf(total, s + per)
            val f = File(dir, "${src.nameWithoutExtension}_c$k.aac")
            f.writeBytes(data.copyOfRange(offs[s], offs[e - 1] + lens[e - 1]))
            out.add(Chunk(f, s * frameSec, (e - s) * frameSec, true))
            if (e >= total) break
            s += step; k++
        }
        return out
    }
}
