package com.example.platehunter

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Sends one recorded street (AAC audio) to Gemini and gets the plates back as JSON. Call from a worker thread. */
object GeminiStreetTranscriber {
    class Item(val street: String, val pin: String, val plate: String, val type: String, val t: Double?, val unclear: Boolean)
    class Result(val items: List<Item>, val notes: String)

    // First choice, then a stable fallback if the first name is not available to this key.
    @Volatile private var goodModel: String? = null
    private val models = listOf("gemini-2.5-flash", "gemini-3-flash-preview")

    private val PROMPT = """
أنت تفرّغ تسجيلًا صوتيًا لشارع (قد يكون هذا المقطع جزءًا من تسجيل أطول، فتجاهل أي لوحة مقطوعة في أول المقطع أو آخره ولا تخمّن أجزاءها) يقرأ فيه المسجِّل لوحات سيارات سعودية بصوته. أعد JSON فقط، بلا أي شرح، بهذا الشكل بالضبط:
{"items":[{"street":"...","pin":"...","plate":"...","type":"...","t":0.0,"unclear":false}],"notes":"..."}

القواعد:
- اللوحة = 3 حروف عربية ثم 4 أرقام بدون مسافات. لو قيلت 3 أرقام أضف صفرًا على اليسار (0752)، ولو رقمان صفرين، وهكذا حتى 4 أرقام.
- الأرقام المقسومة (مثل "64 92") تُدمج في رقم واحد (6492).
- الألف تُكتب ا دائمًا (بدون همزة)، والياء ي وليست ى، والهاء ه وليست هـ.
- لو سمعت "ت" ضمن حروف اللوحة اكتبها ط، واذكر ذلك في notes. لا تغيّر ث ولا خ، وإن لم تكن واضحة ضع unclear=true واذكرها في notes.
- النوع يُقال بعد لوحته، وقيمه: امه، ونيت، تاكسي، ميكروباص، نقل. "وايت" = ونيت، "تاكس" = تاكسي. لوحة بلا نوع تُترك خانة type فارغة. لو قيل نوع قبل أي لوحة في بداية الشارع فتجاهله واذكره في notes.
- اسم الشارع: غالبًا لن يُذكر في التسجيل. إن لم يُذكر اسم شارع فاترك street فارغًا تمامًا ولا تخترع اسمًا. وإن قيل اسم شارع فضعه في street لكل لوحة تليه حتى شارع جديد. كلمة ملتصقة برقم مثل "نقل18" جزء من اسم الشارع، أما "نقل" متبوعة بلوحة فهي نوع.
- "دبوس N" يسري على كل اللوحات بعده حتى دبوس آخر أو شارع جديد، ويُصفَّر عند شارع جديد؛ أول مجموعة بلا دبوس. ضع قيمته (N فقط، بدون كلمة دبوس) في حقل pin، واتركه فارغًا إن لم يوجد. دبوس حرفي (مثل "دبوس ب") يُكتب كما قيل في pin واذكره في notes.
- تجاهل أي كلام ليس لوحة أو اسم شارع أو دبوسًا أو نوعًا.
- حافظ على ترتيب التسجيل ولا تحذف اللوحات المكررة.
- t = الثانية (رقم عشري) من بداية التسجيل التي بدأ عندها نطق اللوحة تقريبًا.
- لا تخمّن حرفًا أو رقمًا غير مسموع؛ اكتب ما سمعته وضع unclear=true.
""".trim()

    private fun cleanPlate(raw: String): Pair<String, Boolean> {
        val s = PlateParser.normDigits(raw).replace("ـ", "").replace(Regex("\\s+"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي')
        val letters = s.takeWhile { it in '\u0621'..'\u064A' }
        val digits = s.drop(letters.length)
        return if (letters.length == 3 && digits.isNotEmpty() && digits.length <= 4 && digits.all { it in '0'..'9' })
            Pair(letters + digits.padStart(4, '0'), false) else Pair(s, true)
    }

    private fun cleanType(raw: String): String {
        val t = raw.trim().replace('ى', 'ي')
        return when (t) {
            "وايت", "وانيت", "ونيت" -> "ونيت"
            "تاكس", "تكسي", "تاكسي" -> "تاكسي"
            "يامه", "ياما", "امه", "أمه", "إمه" -> "امه"
            else -> t
        }
    }

    private fun bodyFor(model: String, b64: String): ByteArray {
        val gen = JSONObject().put("temperature", 0).put("responseMimeType", "application/json")
        if (model.startsWith("gemini-2.5-flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0)) // faster
        return JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/aac").put("data", b64)))
                .put(JSONObject().put("text", PROMPT)))))
            .put("generationConfig", gen)
            .toString().toByteArray(Charsets.UTF_8)
    }

    /** One audio file (up to a few minutes) -> plates. Times in the result are seconds from the start of this file. */
    fun transcribe(apiKey: String, file: File): Result {
        val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        var lastErr = "لم يرد Gemini"
        val order = listOfNotNull(goodModel) + models.filter { it != goodModel }
        for (m in order) {
            val bytes = bodyFor(m, b64)
            var attempt = 0
            while (attempt < 4) {
                attempt++
                var conn: HttpURLConnection? = null
                try {
                    conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 20000; readTimeout = 180000; doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("x-goog-api-key", apiKey)
                        setFixedLengthStreamingMode(bytes.size)
                    }
                    conn.outputStream.use { it.write(bytes) }
                    val code = conn.responseCode
                    if (code in 200..299) {
                        val res = parse(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                        goodModel = m
                        return res
                    }
                    val err = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    lastErr = "HTTP $code ${err.take(160)}"
                    if (code == 401 || code == 403) throw IllegalStateException("مفتاح Gemini غير صحيح أو غير مسموح (HTTP $code)")
                    if (code == 429 || code >= 500) { Thread.sleep(2000L * attempt); continue } // rate limit / server: back off and retry
                    break // 400/404: try the next model
                } catch (e: IOException) {
                    throw IOException("تعذر الاتصال بالإنترنت")
                } finally { conn?.disconnect() }
            }
        }
        throw IllegalStateException(lastErr)
    }

    /**
     * Long recordings (up to ~15 min): split into 50 s chunks with 8 s overlap, transcribe 3 at a time, then stitch.
     * Each plate is taken from exactly one chunk (the one that owns that moment), so nothing is duplicated or cut.
     */
    fun transcribeLong(apiKey: String, file: File, workDir: File, onProgress: (Int, Int) -> Unit): Result {
        val overlap = 8.0
        val chunks = AdtsSplitter.split(file, workDir, 50.0, overlap)
        val total = chunks.size
        val results = arrayOfNulls<Result>(total)
        val errors = ConcurrentLinkedQueue<Throwable>()
        val done = AtomicInteger(0)
        val pool = Executors.newFixedThreadPool(minOf(3, total))
        try {
            val futures = chunks.mapIndexed { i, c ->
                pool.submit {
                    try { results[i] = transcribe(apiKey, c.file) } catch (e: Throwable) { errors.add(e) }
                    finally { if (c.temp) c.file.delete(); onProgress(done.incrementAndGet(), total) }
                }
            }
            futures.forEach { it.get() }
        } finally { pool.shutdown() }
        errors.peek()?.let { throw (it as? Exception ?: IllegalStateException(it.message)) }

        val all = ArrayList<Item>(); val notes = StringBuilder()
        chunks.forEachIndexed { k, c ->
            val r = results[k] ?: return@forEachIndexed
            val lo = if (k == 0) -1.0 else c.startSec + overlap / 2
            val hi = if (k == total - 1) Double.MAX_VALUE else c.startSec + c.lengthSec - overlap / 2
            r.items.forEachIndexed { j, it ->
                val rel = it.t ?: (c.lengthSec * (j + 0.5) / maxOf(1, r.items.size))
                val abs = c.startSec + rel
                if (abs >= lo && abs < hi) all.add(Item(it.street, it.pin, it.plate, it.type, abs, it.unclear))
            }
            if (r.notes.isNotBlank()) notes.append(r.notes).append('\n')
        }
        all.sortBy { it.t }
        // a pin / street stays in force until the next one is spoken (it may have been said in an earlier chunk)
        var pin = ""; var street = ""
        val merged = all.map {
            if (it.pin.isNotBlank()) pin = it.pin
            if (it.street.isNotBlank()) street = it.street
            Item(if (it.street.isBlank()) street else it.street, if (it.pin.isBlank()) pin else it.pin, it.plate, it.type, it.t, it.unclear)
        }
        return Result(merged, notes.toString().trim())
    }

    private fun parse(raw: String): Result {
        val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IllegalStateException("رد فارغ من Gemini")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
        var text = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val obj = if (text.startsWith("[")) JSONObject().put("items", JSONArray(text)) else JSONObject(text)
        val arr = obj.optJSONArray("items") ?: JSONArray()
        val items = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val (plate, bad) = cleanPlate(o.optString("plate"))
            if (plate.isBlank()) continue
            items.add(Item(o.optString("street").trim(), o.optString("pin").replace("دبوس", "").trim(), plate, cleanType(o.optString("type")),
                if (o.has("t") && !o.isNull("t")) o.optDouble("t").takeIf { it.isFinite() } else null,
                bad || o.optBoolean("unclear", false)))
        }
        return Result(items, obj.optString("notes").trim())
    }
}
